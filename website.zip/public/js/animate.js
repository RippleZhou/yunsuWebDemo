/**
 * Created by HUCC on 2016/12/11.
 */
//动画函数

$(function() {
    //头部鼠标经过导航
    var li = $(".nav-menu").find("li"),
        ol = $(".menu-content").find("li")
    li.on("click", function() {
        console.log(1);
        var $this = $(this),
            index = $this.index();
        $this.addClass("active").siblings().removeClass("active");
        ol.eq(index).addClass("active").siblings().removeClass("active");
    })
})

function animate(element, target) {
    if (element.timer) {
        //如果有值，说明已经开启过定时器
        clearInterval(element.timer);
    }
    element.timer = setInterval(function() {
        //leader = leader + step
        var leader = element.offsetLeft;
        var step = 30;
        if (target < leader) {
            step = -step;
        }



        //如果步数是9的话，永远都跑不到重点
        //如果到达终点的距离已经小于一步了，就不跑了，因为你再跑就过了。
        if (Math.abs(target - leader) >= Math.abs(step)) {
            leader = leader + step;
            element.style.left = leader + "px";
        } else {
            clearInterval(element.timer);
            //抱过去
            element.style.left = target + "px";
        }
    }, 150);
}

/**跳转到关于我们界面**/
function selectTab(i){
   window.location.href='about-us.html?selectTab='+i;
}